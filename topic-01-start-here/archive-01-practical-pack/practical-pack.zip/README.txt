LC Computer Science practical pack

Use the matching topic labs at https://github.com/jouwdan/lc-cs .
Python examples use the standard library; notebook code is Python 3.
Run solution.py or solutions.py files from their own folder; each includes checks.
For information-system/server.py, use --check for checks, or run normally and open http://127.0.0.1:8000 .
Use node operator-checks.js for the JavaScript comparison.
All data is fictional. Hardware examples are simulations requiring physical calibration before use.
