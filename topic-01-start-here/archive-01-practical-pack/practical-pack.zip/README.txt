LEAVING CERT COMPUTER SCIENCE — PRACTICE FILES

Course: https://tutors.dev/course/lc-cs
Start with the matching numbered lab in Tutors; the file is only part of the task.
Unzip before opening. Use Python 3 and your school's editor. Keep files from one
lab together. You do not need Git or a GitHub account.

code/topic-05-algorithms: paper-algorithm checks and optional runnable Python.
code/topic-06-python: guided ticket/input/group examples.
code/topic-07-data-structures: collections, CSV and text examples.
code/topic-08-search-sort: search, sort, recursion and cost experiments.
code/topic-09-testing: debugging exercises. faulty_booking.py is DELIBERATELY
wrong and should fail an assertion. Use the lab to find and repair the bug.
Other interactive examples wait for keyboard input; read their lab first.

code/analytics: readings.csv, starter.py, solution.py, database_demo.py.
code/simulation: queue model and experiments.
code/embedded: software sensor simulation; no device wiring required.
code/information-system: server.py plus index.html, with local-only demo data.
code/turing: optional Turing-machine demonstration.
code/portfolio: reusable small templates.
code/exam-practice: model answer for the original mock — attempt it first.
notebooks: optional .ipynb files for a school Jupyter-compatible environment;
Tutors also displays saved outputs, so installing a notebook tool is optional.

solution.py and solutions.py are MODEL ANSWERS with self-checks. Do not read
all solutions before attempting the matching tasks. The supplied data is fictional.
These are original teaching files, not SEC Section C starter programs.
